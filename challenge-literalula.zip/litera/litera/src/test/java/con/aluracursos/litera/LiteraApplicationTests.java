package con.aluracursos.litera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LiteraApplicationTests {

	@Test
	void contextLoads() {
	}

}
