package con.aluracursos.litera;

import con.aluracursos.litera.model.Datos;
import con.aluracursos.litera.model.DatosAutor;
import con.aluracursos.litera.model.DatosLibros;
import con.aluracursos.litera.model.Libro;
import con.aluracursos.litera.repository.LibroRepository;
import con.aluracursos.litera.service.ConsumoApi;
import con.aluracursos.litera.service.ConvierteDatos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

@SpringBootApplication
public class LiteraApplication implements CommandLineRunner {

	@Autowired
	private LibroRepository repository;



	public static void main(String[] args) {
		SpringApplication.run(LiteraApplication.class, args);
	}



	@Override
	public void run(String... args) throws Exception {


		var consumoApi = new ConsumoApi();
		var json = consumoApi.obtenerDatos("https://gutendex.com//books/?search=game");
		System.out.println(json);
		ConvierteDatos conversor = new ConvierteDatos();
		Datos datos = conversor.obtenerDatos(json, Datos.class);
//		DatosLibros datosLibros = new DatosLibros();
//		DatosLibros datosLibros = DatosLibros(datos);
		var datos2 = datos.resultados();
		String titulo = datos2.getFirst().titulo();
     	String nombre = String.valueOf(datos2.getFirst().autor().get(0).nombre());
		Integer nacimiento = datos2.getFirst().autor().get(0).fechaDeNacimiento();
		Integer fallecimiento = datos2.getFirst().autor().get(0).fechaDeFallecimiento();
		Integer descargas = datos2.getFirst().numeroDeDescargas();
		System.out.println(datos2);
		System.out.println("Titulo:"+titulo);
		System.out.println("Autor:"+nombre);
		System.out.println("Fecha de Nacimiento:"+nacimiento);
		System.out.println("Fecha de Fallecimiento:"+fallecimiento);
		System.out.println("Cantidad de Descargas	:"+descargas);

//		List<Libro> libros = new ArrayList<>();
//		libros = (List<Libro>) datos2.stream();
	}
}

