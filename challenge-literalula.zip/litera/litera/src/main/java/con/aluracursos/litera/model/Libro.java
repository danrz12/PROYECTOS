package con.aluracursos.litera.model;

import con.aluracursos.litera.service.ConsumoApi;
import con.aluracursos.litera.service.ConvierteDatos;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;


@Entity
@Table(name="libros3")
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long Id;

    @Column(unique = true)
    private  String titulo;

    private  String nombre;

    private  Integer fechaDeNacimiento;

    private  Integer fechaDeFallecimiento;

    private ArrayList idiomas;

    private  Integer  numeroDeDescargas;

//    private List<Libro>




    public Libro(DatosLibros datosLibros, DatosAutor datosAutor){

        var consumoApi = new ConsumoApi();
        var json = consumoApi.obtenerDatos("https://gutendex.com//books/?search=game");
//        System.out.println(json);
        ConvierteDatos conversor = new ConvierteDatos();
        Datos datos = conversor.obtenerDatos(json, Datos.class);


        this.titulo = datos.resultados().getFirst().titulo();
        this.nombre = datosAutor.nombre();
        this.fechaDeNacimiento = datosAutor.fechaDeNacimiento();
        this.fechaDeFallecimiento = datosAutor.fechaDeFallecimiento();
        this.idiomas = datosLibros.idiomas();
        this.numeroDeDescargas = datosLibros.numeroDeDescargas();

    }


    @Override
    public String toString() {
        return
                "titulo='" + titulo + '\'' +
                ", nombre='" + nombre + '\'' +
                ", fechaDeNacimiento=" + fechaDeNacimiento +
                ", fechaDeFallecimiento=" + fechaDeFallecimiento +
                ", idiomas=" + idiomas +
                ", numeroDeDescargas=" + numeroDeDescargas ;
    }


    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getFechaDeNacimiento() {
        return fechaDeNacimiento;
    }

    public void setFechaDeNacimiento(Integer fechaDeNacimiento) {
        this.fechaDeNacimiento = fechaDeNacimiento;
    }

    public Integer getFechaDeFallecimiento() {
        return fechaDeFallecimiento;
    }

    public void setFechaDeFallecimiento(Integer fechaDeFallecimiento) {
        this.fechaDeFallecimiento = fechaDeFallecimiento;
    }

    public ArrayList getIdiomas() {
        return idiomas;
    }

    public void setIdiomas(ArrayList idiomas) {
        this.idiomas = idiomas;
    }

    public Integer getNumeroDeDescargas() {
        return numeroDeDescargas;
    }

    public void setNumeroDeDescargas(Integer numeroDeDescargas) {
        this.numeroDeDescargas = numeroDeDescargas;
    }


}
